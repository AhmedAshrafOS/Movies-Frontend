import React from "react";
import fawryLogo from "../../assets/logo1.png";
import "./navbar.css"; // Importing CSS for clean code
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const NavBar = ({ showSignIn }) => {
  const [isVisible, setIsVisible] = useState(showSignIn);
  const navigate = useNavigate();

  const handleSignIn = () => {
    setIsVisible(false); // Hide the button
    navigate("/login"); // Redirect to the login page
  };
  return (
    <div className="navbar  justify-around  bg-gradient-to-t from-transparent to-black/90">

      <div >
        <img
          onClick={() => navigate("/")}
          style={{ cursor: "pointer" }}
          alt="Fawry Logo"
    
          src={fawryLogo}
          className="h-10 w-40 md:h-12 md:w-56"
        />
      </div>
      {!isVisible && (<div></div>)}
      {isVisible && (
        <div>
        <button
          className="btn btn-ghost bg-yellow-400 min-h-[2.1rem] rounded-[.35rem] h-1 text-black hover:bg-black hover:text-yellow-300"
          onClick={handleSignIn}
        >
          Sign In
        </button>
      </div>
      )}

      {/* <div className="dropdown dropdown-end">
        <div
          tabIndex={0}
          role="button"
          className="btn btn-ghost btn-circle avatar"
        >
          <div className="w-10 rounded-full">
            <img
              alt="Tailwind CSS Navbar component"
              src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.webp"
            />
          </div>
        </div>
        <ul
          tabIndex={0}
          className="menu menu-sm dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow"
        >
          <li>
            <a className="justify-between">
              Profile
              <span className="badge">New</span>
            </a>
          </li>
          <li>
            <a>Settings</a>
          </li>
          <li>
            <a>Logout</a>
          </li>
        </ul>
      </div> */}
    </div>
  );
};

export default NavBar;
